# Quick Setup Guide

## Step 1: Install Dependencies

```bash
npm run install:all
```

This will install dependencies for the root, frontend, and backend.

## Step 2: Configure MongoDB

1. Create a `.env` file in the `backend` folder:
   ```bash
   cd backend
   cp .env.example .env
   ```

2. Edit `backend/.env` and add your MongoDB connection string:
   ```env
   MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/medusa-feedback
   PORT=5000
   NODE_ENV=development
   ```

   **For MongoDB Atlas:**
   - Sign up at https://www.mongodb.com/cloud/atlas
   - Create a free cluster
   - Get your connection string from "Connect" → "Connect your application"
   - Replace `<password>` with your database password
   - Replace `<database>` with your database name (e.g., `medusa-feedback`)

   **For Local MongoDB:**
   ```env
   MONGODB_URI=mongodb://localhost:27017/medusa-feedback
   ```

## Step 3: Seed Sample Teams

Run the seed script to create sample teams in your database:

```bash
cd backend
npm run seed
```

This will create 5 sample teams (TEAM-001 through TEAM-005) that you can use for testing.

## Step 4: Start the Application

From the root directory:

```bash
npm run dev
```

This starts both frontend and backend servers:
- **Frontend:** http://localhost:3000
- **Backend:** http://localhost:5000

## Step 5: Test the Application

1. Open http://localhost:3000 in your browser
2. Click "Give Feedback"
3. Enter a Team ID (e.g., `TEAM-001`)
4. Submit your feedback with a rating and message
5. See your feedback appear on the home page!

## Troubleshooting

### Port Already in Use
If port 3000 or 5000 is already in use:
- **Frontend:** Edit `frontend/vite.config.js` and change the port
- **Backend:** Edit `backend/.env` and change the PORT value

### MongoDB Connection Failed
- Check your connection string in `backend/.env`
- For MongoDB Atlas, ensure your IP is whitelisted (0.0.0.0/0 for development)
- Verify your database credentials are correct

### Module Not Found Errors
Make sure you've run `npm run install:all` from the root directory.

## Next Steps

- Add more teams to your database
- Customize the UI colors and styling
- Deploy to Vercel/Netlify (frontend) and Railway/Render (backend)
- Add more features from the "Nice-to-Have" list!

