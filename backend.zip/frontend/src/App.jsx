import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Home from './pages/Home'
import VerifyTeam from './pages/VerifyTeam'
import FeedbackForm from './pages/FeedbackForm'

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/verify" element={<VerifyTeam />} />
        <Route path="/feedback/:teamId" element={<FeedbackForm />} />
      </Routes>
    </Router>
  )
}

export default App

