function FeedbackCard({ feedback }) {
  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, i) => (
      <span
        key={i}
        className={i < rating ? 'text-yellow-400' : 'text-gray-300'}
      >
        ★
      </span>
    ))
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-xl transition-shadow duration-200 border border-gray-100">
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="font-semibold text-gray-900 text-lg">
            {feedback.teamName || feedback.teamId}
          </h3>
          <p className="text-sm text-gray-500">{feedback.teamId}</p>
        </div>
        <div className="text-right">
          <div className="text-2xl mb-1">{renderStars(feedback.rating)}</div>
          <p className="text-xs text-gray-500">
            {formatDate(feedback.createdAt)}
          </p>
        </div>
      </div>

      {/* Message */}
      <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">
        {feedback.message}
      </p>
    </div>
  )
}

export default FeedbackCard

