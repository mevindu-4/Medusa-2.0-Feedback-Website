import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'
import FeedbackCard from '../components/FeedbackCard'
import LoadingSpinner from '../components/LoadingSpinner'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'

function Home() {
  const [feedbacks, setFeedbacks] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const navigate = useNavigate()

  useEffect(() => {
    fetchFeedbacks()
    // Poll for new feedbacks every 5 seconds
    const interval = setInterval(fetchFeedbacks, 5000)
    return () => clearInterval(interval)
  }, [])

  const fetchFeedbacks = async () => {
    try {
      const response = await axios.get(`${API_URL}/feedback/all`)
      // Sort by newest first (createdAt descending)
      const sorted = response.data.sort((a, b) => 
        new Date(b.createdAt) - new Date(a.createdAt)
      )
      setFeedbacks(sorted)
      setError(null)
    } catch (err) {
      setError('Failed to load feedbacks. Please try again later.')
      console.error('Error fetching feedbacks:', err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <header className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-2">
            Medusa 2.0 Feedback Wall
          </h1>
          <p className="text-gray-600 text-lg">
            Share your experience with us
          </p>
        </header>

        {/* CTA Button */}
        <div className="flex justify-center mb-8">
          <button
            onClick={() => navigate('/verify')}
            className="bg-red-600 hover:bg-red-700 text-white font-semibold py-3 px-8 rounded-lg shadow-lg transform transition-all duration-200 hover:scale-105 hover:shadow-xl focus:outline-none focus:ring-4 focus:ring-red-300"
          >
            Give Feedback
          </button>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="flex justify-center items-center py-20">
            <LoadingSpinner />
          </div>
        )}

        {/* Error State */}
        {error && !loading && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6 text-center">
            {error}
          </div>
        )}

        {/* Feedbacks Grid */}
        {!loading && !error && (
          <>
            {feedbacks.length === 0 ? (
              <div className="text-center py-20">
                <p className="text-gray-500 text-xl">
                  No feedbacks yet. Be the first to share your thoughts!
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {feedbacks.map((feedback) => (
                  <FeedbackCard key={feedback._id} feedback={feedback} />
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}

export default Home

